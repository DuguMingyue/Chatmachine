/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
char history[6][50];
int status[6][1];
int index = 0;
int linkstate = -1;
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
osThreadId WaitForConnHandle;
osThreadId ReceiveHandle;
osThreadId TransmitHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void waitForConnFunc(void const * argument);
void receiveTask(void const * argument);
void transmitTask(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of WaitForConn */
  osThreadDef(WaitForConn, waitForConnFunc, osPriorityNormal, 0, 128);
  WaitForConnHandle = osThreadCreate(osThread(WaitForConn), NULL);

  /* definition and creation of Receive */
  osThreadDef(Receive, receiveTask, osPriorityNormal, 0, 128);
  ReceiveHandle = osThreadCreate(osThread(Receive), NULL);

  /* definition and creation of Transmit */
  osThreadDef(Transmit, transmitTask, osPriorityNormal, 0, 128);
  TransmitHandle = osThreadCreate(osThread(Transmit), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_waitForConnFunc */
/**
  * @brief  Function implementing the WaitForConn thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_waitForConnFunc */
void waitForConnFunc(void const * argument)
{
  /* USER CODE BEGIN waitForConnFunc */
  /* Infinite loop */
  for(;;)
  {
	char link = {"on"};
	HAL_UART_Transmit(&huart2, (uint8_t*)link, strlen(link), HAL_MAX_DELAY);
	HAL_UART_Receive_IT(&huart2, (uint8_t *)rxBuffer0, 1);
	if(rxBuffer0 == 'on'){linkstate = 1;}
	else{linkstate = 0;}
	rxBuffer0.clear();

	char msg = {"Link disconnect!"};
	if(linkstate == 0){HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
	//LED常亮
	linkstate = -1;}

	//linkstate -> LED
	osDelay(1000);


  }
  /* USER CODE END waitForConnFunc */
}

/* USER CODE BEGIN Header_receiveTask */
/**
* @brief Function implementing the Receive thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_receiveTask */
void receiveTask(void const * argument)
{
  /* USER CODE BEGIN receiveTask */
  /* Infinite loop */
  for(;;)
  {
	//需修改
	HAL_UART_Receive_IT(&huart1, (uint8_t *)rxBuffer1, 1);
	char msg[20];
	sprintf(msg, "%s", rxBuffer1);
	while(msg != ''){
		HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);

	}


    rxBuffer1.clear();

    //LCD

    osDelay(100);
  }
  /* USER CODE END receiveTask */


/* USER CODE BEGIN Header_transmitTask */
/**
* @brief Function implementing the Transmit thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_transmitTask */
void transmitTask(void const * argument)
{
  /* USER CODE BEGIN transmitTask */
  /* Infinite loop */
  for(;;)
  {
	  //需修改
	  	HAL_UART_Receive_IT(&huart2, (uint8_t *)rxBuffer2, 1);
	  	char msg[20];
	  	sprintf(msg, "%u\r\n", rxBuffer1);
	  	while(msg != ''){
	  		HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
	  	}

	      rxBuffer2.clear();
	      osDelay(100);
	    }

        //LCD

  /* USER CODE END transmitTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
